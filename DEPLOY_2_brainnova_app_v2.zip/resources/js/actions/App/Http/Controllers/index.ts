import ContactController from './ContactController'
import NewsletterController from './NewsletterController'
import Settings from './Settings'
const Controllers = {
    ContactController: Object.assign(ContactController, ContactController),
NewsletterController: Object.assign(NewsletterController, NewsletterController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers